import os
import json
import logging
from typing import Any, Dict, Optional, Tuple, List
from urllib.parse import quote


import yaml
import lark_oapi as lark
from lark_oapi.api.sheets.v3 import (
    QuerySpreadsheetSheetRequest,
    QuerySpreadsheetSheetResponse,
)


class FeishuClient:
    """
    最小实现：仅鉴权 + v3 Query 列表工作表
    """

    def __init__(
        self,
        app_id: Optional[str] = None,
        app_secret: Optional[str] = None,
        config_path: Optional[str] = None,
        log_level: lark.LogLevel = lark.LogLevel.DEBUG,
    ) -> None:
        self._logger = logging.getLogger("xpj.feishu")
        app_id, app_secret = self._load_credentials(app_id, app_secret, config_path)
        self.client = (
            lark.Client.builder()
            .app_id(app_id)
            .app_secret(app_secret)
            .log_level(log_level)
            .build()
        )

    def _load_credentials(
        self,
        app_id: Optional[str],
        app_secret: Optional[str],
        config_path: Optional[str],
    ) -> Tuple[str, str]:
        if app_id and app_secret:
            return app_id, app_secret
        env_app_id = os.getenv("FEISHU_APP_ID")
        env_app_secret = os.getenv("FEISHU_APP_SECRET")
        if env_app_id and env_app_secret:
            return env_app_id, env_app_secret
        default_path = config_path or os.path.join(
            os.path.dirname(__file__), "..", "configs", "xpj.feishu.yaml"
        )
        default_path = os.path.abspath(default_path)
        with open(default_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        auth = data.get("auth", {})
        fid = auth.get("app_id")
        fsecret = auth.get("app_secret")
        if not fid or not fsecret:
            raise ValueError(
                "Feishu credentials not found. Set FEISHU_APP_ID/FEISHU_APP_SECRET or provide in configs/xpj.feishu.yaml under auth.app_id/auth.app_secret"
            )
        return fid, fsecret
    
     # ---------- Drive v1：列出指定文件夹下的文件（单页） ----------
    def list_drive_files(
        self,
        folder_token: str,
        page_size: int = 50,
        page_token: Optional[str] = None,
        order_by: str = "EditedTime",
        direction: str = "DESC",
        user_id_type: str = "open_id",
    ) -> Dict[str, Any]:
        """
        使用 lark-oapi SDK 调用 Drive v1 列表接口，返回单页结果。
        如需翻页，请传入上页的 page_token。
        返回值为原生 response.data 对象（便于 lark.JSON.marshal 打印）。
        """
        try:
            from lark_oapi.api.drive.v1 import ListFileRequest, ListFileResponse
        except ModuleNotFoundError as e:
            raise NotImplementedError(
                "当前 lark-oapi 版本未提供 drive.v1 file.list API。请升级到支持的版本（如 >=1.4.15）。"
            ) from e

        builder = (
            ListFileRequest.builder()
            .page_size(page_size)
            .folder_token(folder_token)
            .order_by(order_by)
            .direction(direction)
            .user_id_type(user_id_type)
        )
        if page_token:
            builder = builder.page_token(page_token)
        request = builder.build()

        response: ListFileResponse = self.client.drive.v1.file.list(request)
        if not response.success():
            self._logger.error(
                f"client.drive.v1.file.list failed, code: {response.code}, msg: {response.msg}, "
                f"log_id: {response.get_log_id()}, resp: \n{json.dumps(json.loads(response.raw.content), indent=4, ensure_ascii=False)}"
            )
            raise RuntimeError(f"Drive list failed: {response.code} {response.msg}")

        return response.data if response.data is not None else {}
    
    # ---------- Sheets v3：列出工作表（返回原生响应对象） ----------
    def list_sheets(self, spreadsheet_token: str):
        request: QuerySpreadsheetSheetRequest = (
            QuerySpreadsheetSheetRequest.builder()
            .spreadsheet_token(spreadsheet_token)
            .build()
        )
        response: QuerySpreadsheetSheetResponse = (
            self.client.sheets.v3.spreadsheet_sheet.query(request)
        )
        if not response.success():
            self._logger.error(
                f"client.sheets.v3.spreadsheet_sheet.query failed, code: {response.code}, msg: {response.msg}, "
                f"log_id: {response.get_log_id()}, resp: \n{json.dumps(json.loads(response.raw.content), indent=4, ensure_ascii=False)}"
            )
            raise RuntimeError(f"Sheets query failed: {response.code} {response.msg}")
        try:
            self._logger.info(lark.JSON.marshal(response.data, indent=4))
        except Exception:
            pass
        # 与测试中的实现保持一致，直接返回原生响应对象
        return response

   

    # ---------- Sheets v2：读取指定范围的值（使用 lark 原生 BaseRequest 调用） ----------
    def read_range_values(
        self,
        spreadsheet_token: str,
        range_a1: str,
        value_render_option: str = "ToString",
        date_time_render_option: str = "FormattedString",
    ) -> List[List[Any]]:
        """
        使用 lark-oapi 的原生 BaseRequest 模式调用 v2 valueRange GET 接口。
        不回退到纯 HTTP。
        """
        # URL 中的 range 需要进行 path 安全编码，但保留 '!' 和 ':'
        encoded_range = quote(range_a1, safe="!:")
        uri = f"/open-apis/sheets/v2/spreadsheets/{spreadsheet_token}/values/{encoded_range}"

        request = (
            lark.BaseRequest.builder()
            .http_method(lark.HttpMethod.GET)
            .uri(uri)
            .token_types({lark.AccessTokenType.TENANT})
            .queries([
                ("valueRenderOption", value_render_option),
                ("dateTimeRenderOption", date_time_render_option),
            ])
            .build()
        )

        response: lark.BaseResponse = self.client.request(request)
        if not response.success():
            raise RuntimeError(
                f"valueRange get failed: code={response.code}, msg={response.msg}, log_id={response.get_log_id()}"
            )

        try:
            body = json.loads(response.raw.content.decode("utf-8"))
        except Exception as ex:
            raise RuntimeError(f"invalid json body: {ex}")

        
        values = (
            (body or {}).get("data", {}).get("valueRange", {}).get("values", [])
            or []
        )
        # 统一返回二维数组
        return values


